/*E10*/
#include<stdio.h>
main( )
{
	int arr[10]= {25, 30, 35, 40, 55, 60, 65, 70, 85, 90}, *p;
	for( p = arr+2; p < arr+8; p = p+2 )
		printf("%d   ", *p );
}  
